# ObjectAid
Java-Eclipse ObjectAid UML Explorer

# Installation

Eclipse / Help / Install New Software

Add.. / Archive Button / Select file (**objectaid-1.2.4.zip**)

![image](https://user-images.githubusercontent.com/46564741/164916148-c94a35cd-9249-4aea-a7cf-1908b629f5ff.png)

![image](https://user-images.githubusercontent.com/46564741/164916423-bd047c19-8217-4155-879a-87dd9a7f7069.png)

![image](https://user-images.githubusercontent.com/46564741/164916455-d83c9388-9f6c-49a3-8775-7e0db8fefedf.png)

![image](https://user-images.githubusercontent.com/46564741/164916469-92681fb5-81cd-4cdc-9641-cce1e0e4aec5.png)

![image](https://user-images.githubusercontent.com/46564741/164916479-c177ad33-39ae-4dc5-a9f8-a0f496140250.png)

![image](https://user-images.githubusercontent.com/46564741/164916657-d8e6baee-3a45-46bc-b340-0b07d6b903ae.png)

![image](https://user-images.githubusercontent.com/46564741/164916570-f0f6d481-391c-42e1-bc59-8c63156507f0.png)

![image](https://user-images.githubusercontent.com/46564741/164916750-180c5683-a035-4346-b2aa-8208ce92f001.png)

drag and create...
